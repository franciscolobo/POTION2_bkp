#include <config.h>

#ifndef PART_H
#define PART_H

#include "utilities.h"

#endif

