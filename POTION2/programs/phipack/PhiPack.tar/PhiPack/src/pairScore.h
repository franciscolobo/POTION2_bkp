#ifndef PAIRSCORE
#define PAIRSCORE

int pair_score( align_type **alignment,  int *site_states,int char_a, int char_b, int num_sites, int num_taxa);

#endif
